#这是bank & mysql的Python脚本
#文件夹存放路径"/root/python/mysqlbank"
#1.执行bankdatacreate.sh建立bankdata数据库信息
#mysql -uroot -p123456
#2.执行index.py运行银行储蓄卡系统；
