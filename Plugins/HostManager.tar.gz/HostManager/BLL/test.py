#!/usr/bin/env python
# _*_ coding:utf8 _*_
'''Created on 2016-11-20 @Author:Guolikai'''
import sys
sys.path.append('/root/python/HostManager')
from Model.HostManager import HostGroups,HostUserPasswd
from BLL.TryOperation import TryOperation
from BLL.RemoteCommand import RemoteCommand
import threading
import time
import paramiko
class UserOPS(object):
    def __init__(self):
        pass
    def UserOperation(self):
        print '\033[32;5m###    欢迎使用HostManager系统   ###\033[0m'
        message = ['输入IP直接登录','显示您有权限的主机','显示您有权限的主机组','显示组下的主机','IP组批量执行命令','主机组批量执行命令','批量上传文件','批量下载文件','退出']
        for item in enumerate(message,1):
            print item[0],item[1]
        tryoperation = TryOperation()
        while True:
            your_choice = tryoperation.TryOperationInt('您接下来的操作[1-9]:')
            if your_choice  in range(10):
                return message[your_choice-1]
            else:
                print '\033[32;5m输入的数字超过范围，请在[1-9]选择\033[0m'
                continue
    def InputIp(self):
        ip = raw_input('输入Ip地址直接登录:')
        return ip
    def CheckIp(self,username,ip):
        hostgroups = HostGroups()
        match_result = len(hostgroups.SelectCheckIp(username,ip))
        if match_result == 0:
            print '输入的IP%s不存在' % ip
        else:
            return 'CheckIp Success'
    def RemoteIpComm(self,ip,comm):
        hostget = HostUserPasswd()
        result = hostget.SelectHostUsernamePassword(ip)
        remoteipcomm = RemoteCommand()
        tryoperation = TryOperation()
        for i in range(len(result)):
            dict = result[i]
            user = dict['username']
            pwd = dict['password']
            remoteipcomm.RemoteNetworkComm(ip,user,pwd,comm)

    def GetAuthHost(self,username):
        #显示您有权限的主机
        hostgroups = HostGroups()
        data = hostgroups.SelectIp(username)
        for i in range(len(data)):
            print data[i]['ip']

    def GetAuthHostgroup(self, username):
        #显示您有权限的主机组
        hostgroups = HostGroups()
        data = hostgroups.SelectHostgroup(username)
        for i in range(len(data)):
            print data[i]['hostgroup']

    def GetHostgroupIP(self,username):
        #显示组下的主机
        tryoperation = TryOperation()
        group = tryoperation.TryOperationInput('输入查询的主机组:')
        hostgroups = HostGroups()
        data = hostgroups.SelectHostgroupIp(username,group)
        if len(data)==0:
            if len(hostgroups.SelectHostGROUP) == 0:
                print '输入的主机组%s不存在' % group
            else:
                print '主机组%s,您的权限不够' % group
        else:
            return data

    def BatchGroupComm(self,username):
        data = self.GetHostgroupIP(username)
	while True:
            tryoperation = TryOperation()
            comm = tryoperation.TryOperationInput('登录主机执行的命令:')
            for i in range(len(data)):
                host = data[i]['ip']
                self.RemoteIpComm(host,comm)
            if tryoperation.TryOperationStr('是否继续输入命令') == 'n':
                break
            else:
                continue
    def IpList(self,username):
        tryoperation = TryOperation()
	ip_list = []
	while True:
            ip =  tryoperation.TryOperationInput('输入要批量操作的IP')	
	    if self.CheckIp(username,ip)=='CheckIp Success':
	    	ip_list.append(ip)
            if tryoperation.TryOperationStr('是否继续输入Ip') == 'n':
                return ip_list
            else:
                continue
	 
    def BatchIPComm(self,username):
        tryoperation = TryOperation()
	data = self.IpList(username)
	while True:
            comm = tryoperation.TryOperationInput('登录主机执行的命令:')
            for i in range(len(data)):
                host = data[i]
                self.RemoteIpComm(host,comm)
            if tryoperation.TryOperationStr('是否继续输入命令') == 'n':
                break
            else:
                continue

if __name__ == '__main__':
    while True:
        username = 'root'
        userops = UserOPS()
        result = userops.UserOperation()
        if result == '输入ID直接登录':
            ip = userops.InputIp()
            if userops.CheckIp(username,ip)=='CheckIp Success':
                while True:
                    tryoperation = TryOperation()
                    comm = tryoperation.TryOperationInput('登录主机执行的命令:')
                    userops.RemoteIpComm(ip,comm)
                    if tryoperation.TryOperationStr('是否继续输入命令') == 'n':
                        break
                    else:
                        continue
        elif result =='显示您有权限的主机':
            userops.GetAuthHost(username)
        elif result == '显示您有权限的主机组':
            userops.GetAuthHostgroup(username)
        elif result =='显示组下的主机':
            data = userops.GetHostgroupIP(username)
            for i in range(len(data)):
                print data[i]['ip']
        elif result =='主机组批量执行命令':
            userops.BatchGroupComm(username)
        elif result =='IP组批量执行命令':
            userops.BatchIPComm(username)
        elif result =='批量上传文件':
            pass
        elif result =='批量下载文件':
            pass
        else:
            sys.exit('\033[33;5m您已退出主机管理系统！\033[0m')

if __name__ == '__main__':
    while True:
        username = 'root'
        userops = UserOPS()
        result = userops.UserOperation()
        if result == '输入ID直接登录':
            ip = userops.InputIp()
            if userops.CheckIp(username,ip)=='CheckIp Success':
                while True:
                    tryoperation = TryOperation()
                    comm = tryoperation.TryOperationInput('登录主机执行的命令:')
                    userops.RemoteIpComm(ip,comm)
                    if tryoperation.TryOperationStr('是否继续输入命令') == 'n':
                        break
                    else:
                        continue
        elif result =='显示您有权限的主机':
            userops.GetAuthHost(username)
        elif result == '显示您有权限的主机组':
            userops.GetAuthHostgroup(username)
        elif result =='显示组下的主机':
            data = userops.GetHostgroupIP(username)
            for i in range(len(data)):
                print data[i]['ip']
        elif result =='主机组批量执行命令':
            userops.BatchGroupComm(username)
        elif result =='批量上传文件':
            pass
        elif result =='批量下载文件':
            pass
        else:
            sys.exit('\033[33;5m您已退出主机管理系统！\033[0m')
