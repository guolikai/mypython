#!/usr/bin/env python
# _*_ coding:utf8 _*_
'''Created on 2016-11-20 @Author:Guolikai'''
import paramiko
import sys
import threading
class RemoteCommand(object):
    def __init__(self):
        pass
    def RemoteNetworkComm(slef,host,user,pwd,comm):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            ssh.connect(host,username=user, password=pwd)
        except Exception,e:
            print '%s: Connection Refused' % host
        else:
            stdin, stdout, stderr = ssh.exec_command(comm)
            out = stdout.read()
            err = stderr.read()
            if out:
                print "%s: %s" % (host, out),
            if err:
                print "%s: %s" % (host, err),
        ssh.close()
if __name__ == '__main__':
    if len(sys.argv) != 5:
        print "Usage: %s ip_network user password 'comm'" % sys.argv[0]
        sys.exit(1)
    user  = sys.argv[2]
    password = sys.argv[3]
    comm = sys.argv[4]
    ips = ["%s.%s" % (sys.argv[1],i) for i in range(1, 255)]
    remotecomm = RemoteCommand()
    for ip  in ips:
        t = threading.Thread(target=remotecomm.RemoteNetworkComm, args=(ip,user,password,comm))
        t.start()
