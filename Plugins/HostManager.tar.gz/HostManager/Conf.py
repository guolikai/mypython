#!/usr/bin/env python
# _*_ coding:utf8 _*_
'''Created on 2016-12-1 @Author:Guolikai'''
conn_dict = dict(host='127.0.0.1', user='root', passwd='123456', db='mysql', port=3306)
